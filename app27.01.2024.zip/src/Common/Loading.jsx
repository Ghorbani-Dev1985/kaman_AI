
import loadingGif from "../assets/img/loading.gif";

const Loading = () => {
  return ( 
     <img src={loadingGif} alt="loading" />
   );
}
 
export default Loading;