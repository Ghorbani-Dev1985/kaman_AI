const Line = () => {
    return (<p className="h-px w-full bg-gray-300 dark:bg-white/30 my-5"></p> );
}
 
export default Line;